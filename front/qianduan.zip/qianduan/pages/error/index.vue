<template>
	<view>
		页面访问错误
		会在4s后返回主页
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
